﻿using System;

namespace ATM
{
    class SavingsAccount : Account
    {
        private decimal _interestRate;

        public SavingsAccount(decimal balance, decimal interestRate) : base(balance)
        {
            InterestRate = interestRate;
        }

        public decimal InterestRate
        {
            get { return _interestRate; }
            set
            {
                if (value > 0)
                {
                    _interestRate = value;
                }
                else
                {
                    throw new Exception("Interest rate must be greater than zero");
                }
            }
        }

        public decimal CalculatedInterest()
        {
            return Balance * InterestRate;
        }
    }
}
