﻿
namespace ATM
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.welcomeText = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkingBalanceText = new System.Windows.Forms.Label();
            this.checkingNumberText = new System.Windows.Forms.Label();
            this.savingNumberText = new System.Windows.Forms.Label();
            this.savingBalanceText = new System.Windows.Forms.Label();
            this.refreshButton = new System.Windows.Forms.Button();
            this.logOut = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkingWithdraw = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.savingWithdraw = new System.Windows.Forms.Button();
            this.swAmount = new System.Windows.Forms.TextBox();
            this.cwAmount = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.transferBtn = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.csAmount = new System.Windows.Forms.TextBox();
            this.tsAmount = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tranferCostumerText = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // welcomeText
            // 
            this.welcomeText.AutoSize = true;
            this.welcomeText.Location = new System.Drawing.Point(324, 0);
            this.welcomeText.Name = "welcomeText";
            this.welcomeText.Size = new System.Drawing.Size(35, 13);
            this.welcomeText.TabIndex = 0;
            this.welcomeText.Text = "label1";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkingBalanceText);
            this.groupBox1.Controls.Add(this.checkingNumberText);
            this.groupBox1.Controls.Add(this.savingNumberText);
            this.groupBox1.Controls.Add(this.savingBalanceText);
            this.groupBox1.Controls.Add(this.refreshButton);
            this.groupBox1.Location = new System.Drawing.Point(12, 131);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(234, 162);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Information Display";
            // 
            // checkingBalanceText
            // 
            this.checkingBalanceText.AutoSize = true;
            this.checkingBalanceText.Location = new System.Drawing.Point(11, 105);
            this.checkingBalanceText.Name = "checkingBalanceText";
            this.checkingBalanceText.Size = new System.Drawing.Size(149, 13);
            this.checkingBalanceText.TabIndex = 4;
            this.checkingBalanceText.Text = "Checking Account Balance: $";
            // 
            // checkingNumberText
            // 
            this.checkingNumberText.AutoSize = true;
            this.checkingNumberText.Location = new System.Drawing.Point(11, 47);
            this.checkingNumberText.Name = "checkingNumberText";
            this.checkingNumberText.Size = new System.Drawing.Size(105, 13);
            this.checkingNumberText.TabIndex = 3;
            this.checkingNumberText.Text = "Checking Account #";
            // 
            // savingNumberText
            // 
            this.savingNumberText.AutoSize = true;
            this.savingNumberText.Location = new System.Drawing.Point(11, 16);
            this.savingNumberText.Name = "savingNumberText";
            this.savingNumberText.Size = new System.Drawing.Size(93, 13);
            this.savingNumberText.TabIndex = 2;
            this.savingNumberText.Text = "Saving Account #";
            // 
            // savingBalanceText
            // 
            this.savingBalanceText.AutoSize = true;
            this.savingBalanceText.Location = new System.Drawing.Point(11, 78);
            this.savingBalanceText.Name = "savingBalanceText";
            this.savingBalanceText.Size = new System.Drawing.Size(137, 13);
            this.savingBalanceText.TabIndex = 1;
            this.savingBalanceText.Text = "Saving Account Balance: $";
            // 
            // refreshButton
            // 
            this.refreshButton.Location = new System.Drawing.Point(6, 133);
            this.refreshButton.Name = "refreshButton";
            this.refreshButton.Size = new System.Drawing.Size(222, 23);
            this.refreshButton.TabIndex = 0;
            this.refreshButton.Text = "Refresh Information";
            this.refreshButton.UseVisualStyleBackColor = true;
            this.refreshButton.Click += new System.EventHandler(this.refreshButton_Click);
            // 
            // logOut
            // 
            this.logOut.Location = new System.Drawing.Point(713, 9);
            this.logOut.Name = "logOut";
            this.logOut.Size = new System.Drawing.Size(75, 22);
            this.logOut.TabIndex = 4;
            this.logOut.Text = "Log Out";
            this.logOut.UseVisualStyleBackColor = true;
            this.logOut.Click += new System.EventHandler(this.logOut_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cwAmount);
            this.groupBox2.Controls.Add(this.checkingWithdraw);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.swAmount);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.savingWithdraw);
            this.groupBox2.Location = new System.Drawing.Point(275, 103);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(234, 261);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Withdrawls";
            // 
            // checkingWithdraw
            // 
            this.checkingWithdraw.Location = new System.Drawing.Point(73, 232);
            this.checkingWithdraw.Name = "checkingWithdraw";
            this.checkingWithdraw.Size = new System.Drawing.Size(75, 23);
            this.checkingWithdraw.TabIndex = 5;
            this.checkingWithdraw.Text = "Withdraw";
            this.checkingWithdraw.UseVisualStyleBackColor = true;
            this.checkingWithdraw.Click += new System.EventHandler(this.checkingWithdraw_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(49, 129);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(126, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Withdraw From Checking";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 173);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Amount:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(56, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Withdraw From Savings";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Amount:";
            // 
            // savingWithdraw
            // 
            this.savingWithdraw.Location = new System.Drawing.Point(73, 90);
            this.savingWithdraw.Name = "savingWithdraw";
            this.savingWithdraw.Size = new System.Drawing.Size(75, 23);
            this.savingWithdraw.TabIndex = 4;
            this.savingWithdraw.Text = "Withdraw";
            this.savingWithdraw.UseVisualStyleBackColor = true;
            this.savingWithdraw.Click += new System.EventHandler(this.savingWithdraw_Click);
            // 
            // swAmount
            // 
            this.swAmount.Location = new System.Drawing.Point(63, 43);
            this.swAmount.Name = "swAmount";
            this.swAmount.Size = new System.Drawing.Size(165, 20);
            this.swAmount.TabIndex = 6;
            // 
            // cwAmount
            // 
            this.cwAmount.Location = new System.Drawing.Point(63, 166);
            this.cwAmount.Name = "cwAmount";
            this.cwAmount.Size = new System.Drawing.Size(165, 20);
            this.cwAmount.TabIndex = 7;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tranferCostumerText);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.csAmount);
            this.groupBox3.Controls.Add(this.tsAmount);
            this.groupBox3.Controls.Add(this.transferBtn);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(554, 131);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(234, 162);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Transfer Money";
            // 
            // transferBtn
            // 
            this.transferBtn.Location = new System.Drawing.Point(6, 133);
            this.transferBtn.Name = "transferBtn";
            this.transferBtn.Size = new System.Drawing.Size(222, 23);
            this.transferBtn.TabIndex = 0;
            this.transferBtn.Text = "Transfer";
            this.transferBtn.UseVisualStyleBackColor = true;
            this.transferBtn.Click += new System.EventHandler(this.transferBtn_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "To/From Checkings:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "To/From Savings:";
            // 
            // csAmount
            // 
            this.csAmount.Location = new System.Drawing.Point(116, 71);
            this.csAmount.Name = "csAmount";
            this.csAmount.Size = new System.Drawing.Size(112, 20);
            this.csAmount.TabIndex = 9;
            // 
            // tsAmount
            // 
            this.tsAmount.Location = new System.Drawing.Point(116, 44);
            this.tsAmount.Name = "tsAmount";
            this.tsAmount.Size = new System.Drawing.Size(112, 20);
            this.tsAmount.TabIndex = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(132, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Transfering To Account: #";
            // 
            // tranferCostumerText
            // 
            this.tranferCostumerText.Location = new System.Drawing.Point(141, 18);
            this.tranferCostumerText.Name = "tranferCostumerText";
            this.tranferCostumerText.Size = new System.Drawing.Size(87, 20);
            this.tranferCostumerText.TabIndex = 12;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.logOut);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.welcomeText);
            this.Name = "frmMain";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label welcomeText;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button refreshButton;
        private System.Windows.Forms.Label checkingBalanceText;
        private System.Windows.Forms.Label checkingNumberText;
        private System.Windows.Forms.Label savingNumberText;
        private System.Windows.Forms.Label savingBalanceText;
        private System.Windows.Forms.Button logOut;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button checkingWithdraw;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button savingWithdraw;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox swAmount;
        private System.Windows.Forms.TextBox cwAmount;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox csAmount;
        private System.Windows.Forms.TextBox tsAmount;
        private System.Windows.Forms.Button transferBtn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tranferCostumerText;
        private System.Windows.Forms.Label label7;
    }
}