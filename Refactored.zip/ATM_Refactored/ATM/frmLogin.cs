﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ATM
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        string cs = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Connor Ward\Desktop\ATM\ATM\ATMData.mdf;Integrated Security=True;Connect Timeout=30";
        private void button1_Click(object sender, EventArgs e)
        {
            pinText.Text = pinText.Text + "1";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pinText.Text = pinText.Text + "2";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pinText.Text = pinText.Text + "3";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pinText.Text = pinText.Text + "4";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            pinText.Text = pinText.Text + "5";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            pinText.Text = pinText.Text + "6";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            pinText.Text = pinText.Text + "7";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            pinText.Text = pinText.Text + "8";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            pinText.Text = pinText.Text + "9";
        }

        private void submitBtn_Click(object sender, EventArgs e)
        {
            if (CostumerNumberText.Text == "" || pinText.Text == "")
            {
                MessageBox.Show("Please provide UserName and Password");
                return;
            }
            try
            {
                //Create SqlConnection
                SqlConnection con = new SqlConnection(cs);
                SqlCommand cmd = new SqlCommand("Select * from Users where CostumerNumber=@costumernumber and Pin=@pin", con);
                cmd.Parameters.AddWithValue("@costumernumber", CostumerNumberText.Text);
                cmd.Parameters.AddWithValue("@pin", pinText.Text);
                con.Open();
                SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapt.Fill(ds);
                con.Close();
                int count = ds.Tables[0].Rows.Count;
                if (count == 1)
                {
                    MessageBox.Show("Login Successful!");
                    this.Hide();
                    frmMain fm = new frmMain("Welcome Costumer #" + CostumerNumberText.Text);
                    fm.Show();
                }
                else
                {
                    MessageBox.Show("Login Failed!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void clearPin_Click(object sender, EventArgs e)
        {
            pinText.Text = "";
        }
    }
}
