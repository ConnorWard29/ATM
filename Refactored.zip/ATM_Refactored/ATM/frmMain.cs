﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using static ATM.SQLHelper;

namespace ATM
{
    public partial class frmMain : Form
    {
        public frmMain(string welcome)
        {
            InitializeComponent();
            welcomeText.Text = welcome;
        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            int costumerNumber = int.Parse(Regex.Replace(welcomeText.Text, "[^0-9.]", ""));
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Connor Ward\Desktop\ATM\ATM\ATMData.mdf;Integrated Security=True;Connect Timeout=30";
            cnn = new SqlConnection(connetionString);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("Select * from Users Where CostumerNumber = '" + costumerNumber + "'", cnn);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                savingNumberText.Text = "Saving Account #" + dr["SavingAccountNumber"].ToString();
                checkingNumberText.Text = "Checking Account #" + dr["CheckingAccountNumber"].ToString();
                savingBalanceText.Text = "Saving Account Balance: $" + dr["SavingBalance"].ToString();
                checkingBalanceText.Text = "Checking Account Balance: $" + dr["CheckingBalance"].ToString();
            }
        }

        private void logOut_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmLogin fl = new frmLogin();
            fl.Show();
        }

        private void savingWithdraw_Click(object sender, EventArgs e)
        {
            decimal amount = decimal.Parse(swAmount.Text);
            string type = "s";
            int costumerNumber = int.Parse(Regex.Replace(welcomeText.Text, "[^0-9.]", ""));
            if (amount <= 0)
            {
                MessageBox.Show("Withdrawl amount must be greater than zero");
            }
            else
            {
                withdrawing(amount, type, costumerNumber);
            }
        }

        private void checkingWithdraw_Click(object sender, EventArgs e)
        {
            decimal amount = decimal.Parse(cwAmount.Text);
            string type = "c";
            int costumerNumber = int.Parse(Regex.Replace(welcomeText.Text, "[^0-9.]", ""));
            if (amount <= 0)
            {
                MessageBox.Show("Withdrawl amount must be greater than zero");
            }
            else
            {
                withdrawing(amount, type, costumerNumber);
            }
        }

        private void transferBtn_Click(object sender, EventArgs e)
        {
            decimal sAmount = decimal.Parse(tsAmount.Text);
            decimal cAmount = decimal.Parse(csAmount.Text);
            int costumerNumber = int.Parse(Regex.Replace(welcomeText.Text, "[^0-9.]", ""));
            int tCostumerNumber = int.Parse(tranferCostumerText.Text);
            if (sAmount < 0 || cAmount < 0)
            {
                MessageBox.Show("You must tranfer more than zero dollars");
            }
            transfering(sAmount, cAmount, costumerNumber, tCostumerNumber);
        }
    }
}
