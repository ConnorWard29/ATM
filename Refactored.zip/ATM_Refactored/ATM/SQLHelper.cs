﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ATM
{
    class SQLHelper
    {
        public static void withdrawing(decimal amount, string type, int costumerNumber)
        {
            if (type == "s")
            {
                decimal oldBalance;
                decimal newBalance;
                string connetionString;
                SqlConnection cnn;
                connetionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Connor Ward\Desktop\ATM\ATM\ATMData.mdf;Integrated Security=True;Connect Timeout=30";
                cnn = new SqlConnection(connetionString);
                cnn.Open();

                SqlCommand command;
                SqlDataAdapter adapter = new SqlDataAdapter();
                String sql = String.Empty;

                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter("Select * from Users", cnn);
                da.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    oldBalance = Convert.ToDecimal(dr["SavingBalance"]);
                    newBalance = oldBalance - amount;
                    if (newBalance < 0)
                    {
                        MessageBox.Show("Savings can't go below zero");
                    }
                    else
                    {
                        sql = "Update Users Set SavingBalance = ('" + newBalance + "') Where CostumerNumber = '" + costumerNumber + "'";

                        command = new SqlCommand(sql, cnn);

                        adapter.InsertCommand = new SqlCommand(sql, cnn);
                        adapter.InsertCommand.ExecuteNonQuery();

                        command.Dispose();
                        cnn.Close();
                    }
                    break;
                }
            }
            if (type == "c")
            {
                decimal oldBalance;
                decimal newBalance;
                decimal emergencyFunds;
                string connetionString;
                SqlConnection cnn;
                connetionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Connor Ward\Desktop\ATM\ATM\ATMData.mdf;Integrated Security=True;Connect Timeout=30";
                cnn = new SqlConnection(connetionString);
                cnn.Open();

                SqlCommand command;
                SqlDataAdapter adapter = new SqlDataAdapter();
                String sql = String.Empty;

                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter("Select * from Users", cnn);
                da.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    oldBalance = Convert.ToDecimal(dr["CheckingBalance"]);
                    emergencyFunds = Convert.ToDecimal(dr["SavingBalance"]);
                    newBalance = oldBalance - amount;
                    emergencyFunds = emergencyFunds + newBalance;
                    if (newBalance < 0)
                    {
                        if (emergencyFunds < 0)
                        {
                            MessageBox.Show("The combined total of your savings and checking account wasn't enough to cover the withdrawl");
                        }
                        else
                        {


                            MessageBox.Show("There wasn't enough in your checking account, so the remander was withdrawn from your savings account");

                            sql = "Update Users Set CheckingBalance = ('" + 0 + "') Where CostumerNumber = '" + costumerNumber + "'";

                            command = new SqlCommand(sql, cnn);

                            adapter.InsertCommand = new SqlCommand(sql, cnn);
                            adapter.InsertCommand.ExecuteNonQuery();

                            sql = "Update Users Set SavingBalance = ('" + emergencyFunds + "') Where CostumerNumber = '" + costumerNumber + "'";

                            adapter.InsertCommand = new SqlCommand(sql, cnn);
                            adapter.InsertCommand.ExecuteNonQuery();

                            command.Dispose();
                            cnn.Close();
                        }
                    }
                    else
                    {
                        sql = "Update Users Set CheckingBalance = ('" + newBalance + "') Where CostumerNumber = '" + costumerNumber + "'";

                        command = new SqlCommand(sql, cnn);

                        adapter.InsertCommand = new SqlCommand(sql, cnn);
                        adapter.InsertCommand.ExecuteNonQuery();

                        command.Dispose();
                        cnn.Close();
                    }
                    break;
                }
            }
        }
        public static void transfering(decimal sAmount, decimal cAmount, int costumerNumber, int tCostumerNumber)
        {
            decimal oldSavingAmount;
            decimal oldCheckingAmount;
            decimal newSavingAmount;
            decimal newCheckingAmount;
            string connetionString;
            int counter = 0;

            SqlConnection cnn;
            connetionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Connor Ward\Desktop\ATM\ATM\ATMData.mdf;Integrated Security=True;Connect Timeout=30";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            SqlCommand command;
            SqlDataAdapter adapter = new SqlDataAdapter();
            String sql = String.Empty;

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("Select * from Users", cnn);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                oldCheckingAmount = Convert.ToDecimal(dr["CheckingBalance"]);
                oldSavingAmount = Convert.ToDecimal(dr["SavingBalance"]);
                if (counter < 1)
                {
                    newCheckingAmount = oldCheckingAmount - cAmount;
                    newSavingAmount = oldSavingAmount - sAmount;
                    sql = "Update Users Set SavingBalance = ('" + newSavingAmount + "') Where CostumerNumber = '" + costumerNumber + "'";

                    command = new SqlCommand(sql, cnn);
                    if (newCheckingAmount < 0 || newSavingAmount < 0)
                    {
                        MessageBox.Show("You can't tranfer more money than you have in your account");
                        counter++;
                    }
                    else
                    {
                        adapter.InsertCommand = new SqlCommand(sql, cnn);
                        adapter.InsertCommand.ExecuteNonQuery();

                        sql = "Update Users Set CheckingBalance = ('" + newCheckingAmount + "') Where CostumerNumber = '" + costumerNumber + "'";

                        command = new SqlCommand(sql, cnn);

                        adapter.InsertCommand = new SqlCommand(sql, cnn);
                        adapter.InsertCommand.ExecuteNonQuery();
                    }

                }
                else
                {
                    newCheckingAmount = oldCheckingAmount + cAmount;
                    newSavingAmount = oldSavingAmount + sAmount;
                    sql = "Update Users Set SavingBalance = ('" + newSavingAmount + "') Where CostumerNumber = '" + tCostumerNumber + "'";

                    command = new SqlCommand(sql, cnn);

                    adapter.InsertCommand = new SqlCommand(sql, cnn);
                    adapter.InsertCommand.ExecuteNonQuery();

                    sql = "Update Users Set CheckingBalance = ('" + newCheckingAmount + "') Where CostumerNumber = '" + tCostumerNumber + "'";

                    command = new SqlCommand(sql, cnn);

                    adapter.InsertCommand = new SqlCommand(sql, cnn);
                    adapter.InsertCommand.ExecuteNonQuery();
                }
                counter++;
                command.Dispose();
                while (counter == 2)
                {
                    cnn.Close();
                    break;
                }
            }
        }

    }
}
