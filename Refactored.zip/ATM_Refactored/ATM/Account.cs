﻿using System;

namespace ATM
{
    class Account
    {
        private decimal _balance;

        public Account(decimal balance)
        {
            Balance = balance;
        }

        public decimal Balance
        {
            get { return _balance; }
            set
            {
                if (value >= 0)
                {
                    _balance = value;
                }
                else
                {
                    throw new Exception("Balance cannor be negative");
                }
            }
        }
        public virtual void Credit(decimal amount)
        {
            if (amount > 0)
            {
                Balance += amount;
            }
            else
            {
                throw new Exception("Credited amount must be greater than zero");
            }
        }
        public virtual bool Debit(decimal amount)
        {
            bool Withdrawn = true;
            if (Balance - amount >= 0)
            {
                Balance -= amount;
                Withdrawn = true;
            }
            else
            {
                Withdrawn = false;
            }

            return Withdrawn;
        }
    }
}
